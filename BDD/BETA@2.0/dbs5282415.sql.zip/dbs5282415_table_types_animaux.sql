
--
-- Déchargement des données de la table `types_animaux`
--

INSERT INTO `types_animaux` (`idtypes_animaux`, `nom`, `url_icone`) VALUES
(1, 'Poule', NULL),
(2, 'Chat', NULL),
(3, 'Chien', NULL),
(4, 'Autre', NULL),
(5, 'Rongeur', NULL),
(6, 'Reptile', NULL),
(7, 'Poisson', NULL),
(8, 'Crustacé', NULL),
(9, 'Insecte', NULL),
(10, 'Amphibien', NULL),
(11, 'Oiseau', NULL),
(12, 'Furet', NULL),
(13, 'Lapin', NULL);
