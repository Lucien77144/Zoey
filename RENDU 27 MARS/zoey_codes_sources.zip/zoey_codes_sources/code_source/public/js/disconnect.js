document.addEventListener("DOMContentLoaded", function(){

    // Rediriger sur la page principale au bout de 2 secondes
    setTimeout(() => {
        window.location="index.php";
    }, 2000);

});