<?php
$host = "localhost";
$dbname = "zoey_database";
$username = "root";
$password = "";
